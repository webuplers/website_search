<?php 
/* Template Name: Movies */
get_header();
?>
<div class="container">
<div class="sec_project_listing">
    <div class="row">
        <div class="col-md-12">
            <div class="search_wrap">
                <input type="text" placeholder="Search red, green, blue or yellow" id="text">
                <input type="submit" id="search">
            </div>
        </div>
    </div>
    <div class="block_listing_wrap">
        <!--<div class="block_cta">
            <div class="block_content_wrap">
                <div class="block_content">
                    <h3>Stratford Substation</h3>
                    <ul>
                        <li><span>Year:</span> Port of Tauranga</li>
                        <li><span>Runtime:</span> 2014</li>
                    </ul>
                </div>
            </div>
            <div class="block_img">
                <div class="bg_img" style="background-image: url('https://staging.project-progress.net/projects/connell/wp-content/uploads/2021/11/project_img.jpg')"></div>
            </div>
        </div>-->
    </div>
</div>
</div>
<?php get_footer(); ?>